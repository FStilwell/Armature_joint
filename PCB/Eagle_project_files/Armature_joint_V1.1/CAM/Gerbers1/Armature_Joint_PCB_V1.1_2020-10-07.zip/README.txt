Board Dimensions:
 Approximately 35mm X 35mm circular
 2 Layers
 1.6mm Thickness	
 Silkscreen on top layer only



Gerber Files:

copper_bottom.gbr - Bottom layer

copper_top.gbr - Top layer


Soldermask offset per your process.



Special Instructions:
No added copper around the PCB antenna where ground planes stop


Contact info:


traveler.hauptman@mechadept.com

022 627 1529